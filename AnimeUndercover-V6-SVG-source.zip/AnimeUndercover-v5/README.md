# Anime Undercover — V6

V6 is based on the user's tested V5 project. It preserves the existing character packs, custom pairs, themes, sound, vibration, and Android WebView shell.

## Changes in this source
- Session model: one game contains any number of rounds.
- After a round, players can continue with the same participants or finish the session.
- Scoring mode is selected at session start: Classic V5 or Bonus V6.
- Session totals and role counts are stored for the session.
- The last 10 completed sessions are stored locally with round summaries and scoring mode.
- Victory condition updated: Undercover win when Undercover outnumber Civilians, or in the final 1 Undercover vs 1 Civil duel. Civilians win when all Undercover and Mr. White are eliminated.
- Android version updated to 6.0.

## Important known limitation
The current V5 gameplay uses one collective target selection for elimination; it does not record each participant's individual secret vote. Therefore the Civil `correct_vote` bonus cannot be reliably awarded yet. The UI explicitly notes this. A true sequential secret-voting phase is needed before that bonus can be enabled. The Undercover last-survivor (+1) and Mr. White survival (+2) bonuses are implemented.

## Build
Use the included GitHub Actions workflow or build with Android Gradle Plugin 8.7.3, JDK 17, and Android SDK platform 34.
