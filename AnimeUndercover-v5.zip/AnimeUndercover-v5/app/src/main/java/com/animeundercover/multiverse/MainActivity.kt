package com.animeundercover.multiverse

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView

    inner class AndroidBridge(private val context: Context) {
        @JavascriptInterface
        fun vibrate(ms: Long) {
            try {
                val vib = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (vib != null && vib.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        vib.vibrate(ms)
                    }
                }
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun setSystemBars(bgHex: String, isLight: Boolean) {
            runOnUiThread {
                try {
                    val color = Color.parseColor(bgHex)
                    window.statusBarColor = color
                    window.navigationBarColor = color
                    webView.setBackgroundColor(color)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        var flags = window.decorView.systemUiVisibility
                        flags = if (isLight) {
                            flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                        } else {
                            flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
                        }
                        window.decorView.systemUiVisibility = flags
                    }
                } catch (_: Exception) {}
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bgColor = Color.parseColor("#0B1020")
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor

        webView = WebView(this).apply {
            setBackgroundColor(bgColor)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.loadsImagesAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            addJavascriptInterface(AndroidBridge(this@MainActivity), "AndroidBridge")
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/index.html")
        }

        setContentView(webView)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        webView.evaluateJavascript("if(typeof handleAndroidBack==='function')handleAndroidBack();else false;") { result ->
            if (result != "true") {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    super.onBackPressed()
                }
            }
        }
    }
}
