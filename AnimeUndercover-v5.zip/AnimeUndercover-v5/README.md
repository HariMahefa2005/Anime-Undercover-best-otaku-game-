# Anime Undercover v5.0 — Thèmes Sombre/Clair & Couleurs Personnalisées

Projet Android complet (`com.animeundercover.multiverse`) incluant :
1. **Menu Thème & Couleurs (`🎨`)** accessible depuis l'accueil, la configuration et le plateau de jeu :
   - Bascule instantanée **🌙 Mode Sombre / ☀️ Mode Clair** (synchronisée avec la barre d'état Android).
   - **6 palettes prédéfinies** : *Multiverse, Sakura, Akatsuki, Émeraude, Océan, Roi Soleil*.
   - **Sélecteur de couleurs libres** (principale et secondaire) qui adapte aussi les boutons, le logo et le dos des cartes mystères.
2. **Photos officielles des personnages + Nom de l'anime** (`📺 Jujutsu Kaisen`, `📺 Berserk`, etc.).
3. **Tableau des scores cumulés (`🏆`)**, filtres de difficulté et effets sonores/vibrations.
