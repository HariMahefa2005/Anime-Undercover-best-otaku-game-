# Anime Undercover v4.0 — Édition Tournoi (Shonen & Seinen)

Projet Android complet (`com.animeundercover.multiverse`) incluant :
1. **Nom de l'anime sous chaque personnage** (`📺 Jujutsu Kaisen`, `📺 Berserk`, etc.) en plus de sa photo officielle.
2. **Tableau des scores cumulés (Mode Tournoi / Soirée)** avec podium (`🥇 🥈 🥉`) et attribution automatique des points en fin de manche.
3. **Effets sonores (Web Audio) & Vibrations natives Android** (activables/désactivables via le bouton `🔊 / 🔇`).
4. **Filtre de difficulté des paires** (`🌟 Grand Public`, `🔥 Otaku`, `⚡ Toutes`) combinable avec les catégories `Shonen`, `Seinen` et `Mixte`.
5. **Révélation classique par simple toucher** + bouton `✓ OK, j'ai mémorisé`.
